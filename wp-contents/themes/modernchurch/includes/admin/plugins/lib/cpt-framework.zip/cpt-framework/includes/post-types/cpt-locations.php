<?php

  add_action( 'init', 'cpt_locations' );
	function cpt_locations() {
		
		// Define all the labels
		$labels = array(
			'name'               => _x( 'Locations', 'post type general name', 'cpt' ),
			'singular_name'      => _x( 'Location', 'post type singular name', 'cpt' ),
			'menu_name'          => _x( 'CPT Locations', 'admin menu', 'cpt' ),
			'add_new'            => _x( 'Add New Location', 'Location', 'cpt' ),
			'add_new_item'       => __( 'Add New Location', 'cpt' ),
			'edit_item'          => __( 'Edit Location', 'cpt' ),
			'new_item'           => __( 'New Location', 'cpt' ),
			'all_items'          => __( 'All Locations', 'cpt' ),
			'view_item'          => __( 'View Location', 'cpt' ),
			'search_items'       => __( 'Search Locations', 'cpt' ),
			'not_found'          => __( 'No Locations found', 'cpt' ),
			'not_found_in_trash' => __( 'No Locations found in the Trash', 'cpt' ), 
			'parent_item_colon'  => ''
		);
		
		$args = array(
			'labels'        		=> $labels,
			'description'   		=> 'Holds the content for the Locations',
			'public'        		=> true,
			'rewrite'				=> array(
											'slug'	=> 'locations'
										),
			'menu_icon'				=> 'dashicons-location',
			'supports'      		=> array( 'title', 'editor', 'thumbnail' ),
			'has_archive'   		=> false,
		);
		
		register_post_type( 'cpt_locations', $args );	
	}

	add_filter( 'post_updated_messages', 'cpt_locations_messages' );
	function cpt_locations_messages( $messages ) {
		global $post, $post_ID;
		$messages['cpt_locations'] = array(
			0 => '', 
			1 => sprintf( __('Location updated. <a href="%s">View Location</a>'), esc_url( get_permalink($post_ID) ) ),
			2 => __('Custom field updated.'),
			3 => __('Custom field deleted.'),
			4 => __('Custom field updated.'),
			5 => isset($_GET['revision']) ? sprintf( __('Location restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
			6 => sprintf( __('Location published. <a href="%s">View Location</a>'), esc_url( get_permalink($post_ID) ) ),
			7 => __('Location saved.'),
			8 => sprintf( __('Location submitted. <a target="_blank" href="%s">Preview Location</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
			9 => sprintf( __('Location scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Location</a>'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
			10 => sprintf( __('Location draft updated. <a target="_blank" href="%s">Preview Location</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		);
		return $messages;
	}

?>