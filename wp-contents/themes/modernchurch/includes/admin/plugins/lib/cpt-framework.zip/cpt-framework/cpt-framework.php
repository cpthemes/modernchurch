<?php

/*
Plugin Name: CPT Framework
Plugin URI: http://www.cpthemes.com
Description: This framework was to add additional functionality to CPThemes
Version: ALPHA
Author: CP Themes
Author URI: http://www.cpthemes.com
*/


// Require Custom Post Types
$directory = (__DIR__) . '/includes/post-types';
$post_types_array = scandir($directory);

foreach( $post_types_array as $post_type ) {

	if ( ! in_array($post_type, array( '.','..' ) ) ) {
		$post_type_url = 'includes/post-types/'.$post_type;
		require_once( "$post_type_url" );
	}

}


// Require Meta Fields
require_once( 'includes/meta-fields/cpt-meta-fields.php' );