<?php

  add_action( 'init', 'cpt_staff' );
	function cpt_staff() {
		
		// Define all the labels
		$labels = array(
			'name'               => _x( 'Staffs', 'post type general name', 'cpt' ),
			'singular_name'      => _x( 'Staff', 'post type singular name', 'cpt' ),
			'menu_name'          => _x( 'CPT Staff', 'admin menu', 'cpt' ),
			'add_new'            => _x( 'Add New Staff', 'Staff', 'cpt' ),
			'add_new_item'       => __( 'Add New Staff', 'cpt' ),
			'edit_item'          => __( 'Edit Staff', 'cpt' ),
			'new_item'           => __( 'New Staff', 'cpt' ),
			'all_items'          => __( 'All Staffs', 'cpt' ),
			'view_item'          => __( 'View Staff', 'cpt' ),
			'search_items'       => __( 'Search Staffs', 'cpt' ),
			'not_found'          => __( 'No Staffs found', 'cpt' ),
			'not_found_in_trash' => __( 'No Staffs found in the Trash', 'cpt' ), 
			'parent_item_colon'  => ''
		);
		
		$args = array(
			'labels'        		=> $labels,
			'description'   		=> 'Holds the content for the Staffs',
			'public'        		=> true,
			'rewrite'				=> array(
											'slug'	=> 'staff'
										),
			'menu_icon'				=> 'dashicons-groups',
			'capability_type'    	=> 'post',
			'supports'      		=> array( 'title', 'editor', 'thumbnail' ),
			'has_archive'   		=> false,
		);
		
		register_post_type( 'cpt_staff', $args );	
	}

	add_filter( 'post_updated_messages', 'cpt_staff_messages' );
	function cpt_staff_messages( $messages ) {
		global $post, $post_ID;
		$messages['cpt_staff'] = array(
			0 => '', 
			1 => sprintf( __('Staff updated. <a href="%s">View Staff</a>'), esc_url( get_permalink($post_ID) ) ),
			2 => __('Custom field updated.'),
			3 => __('Custom field deleted.'),
			4 => __('Custom field updated.'),
			5 => isset($_GET['revision']) ? sprintf( __('Staff restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
			6 => sprintf( __('Staff published. <a href="%s">View Staff</a>'), esc_url( get_permalink($post_ID) ) ),
			7 => __('Staff saved.'),
			8 => sprintf( __('Staff submitted. <a target="_blank" href="%s">Preview Staff</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
			9 => sprintf( __('Staff scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Staff</a>'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
			10 => sprintf( __('Staff draft updated. <a target="_blank" href="%s">Preview Staff</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		);
		return $messages;
	}

?>