<?php

  add_action( 'init', 'cpt_slider' );
	function cpt_slider() {
		
		// Define all the labels
		$labels = array(
			'name'               => _x( 'Slides', 'post type general name', 'cpt' ),
			'singular_name'      => _x( 'Slide', 'post type singular name', 'cpt' ),
			'menu_name'          => _x( 'CPT HP Slideshow', 'admin menu', 'cpt' ),
			'add_new'            => _x( 'Add New Slide', 'Slide', 'cpt' ),
			'add_new_item'       => __( 'Add New Slide', 'cpt' ),
			'edit_item'          => __( 'Edit Slide', 'cpt' ),
			'new_item'           => __( 'New Slide', 'cpt' ),
			'all_items'          => __( 'All Slides', 'cpt' ),
			'view_item'          => __( 'View Slide', 'cpt' ),
			'search_items'       => __( 'Search Slides', 'cpt' ),
			'not_found'          => __( 'No Slides found', 'cpt' ),
			'not_found_in_trash' => __( 'No Slides found in the Trash', 'cpt' ), 
			'parent_item_colon'  => ''
		);
		
		$args = array(
			'labels'        		=> $labels,
			'description'   		=> 'Holds the content for the Slides',
			'public'        		=> false,
			'show_ui'				=> true,
			'show_in_menu'			=> true,
			'menu_icon'				=> 'dashicons-format-gallery',
			'supports'      		=> array( 'title', 'editor', 'thumbnail' ),
			'has_archive'   		=> false,
		);
		
		register_post_type( 'cpt_slider', $args );	
	}

	add_filter( 'post_updated_messages', 'cpt_slider_messages' );
	function cpt_slider_messages( $messages ) {
		global $post, $post_ID;
		$messages['cpt_slider'] = array(
			0 => '', 
			1 => sprintf( __('Slide updated. <a href="%s">View Slide</a>'), esc_url( get_permalink($post_ID) ) ),
			2 => __('Custom field updated.'),
			3 => __('Custom field deleted.'),
			4 => __('Custom field updated.'),
			5 => isset($_GET['revision']) ? sprintf( __('Slide restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
			6 => sprintf( __('Slide published. <a href="%s">View Slide</a>'), esc_url( get_permalink($post_ID) ) ),
			7 => __('Slide saved.'),
			8 => sprintf( __('Slide submitted. <a target="_blank" href="%s">Preview Slide</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
			9 => sprintf( __('Slide scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Slide</a>'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
			10 => sprintf( __('Slide draft updated. <a target="_blank" href="%s">Preview Slide</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		);
		return $messages;
	}

?>