<?php

  add_action( 'init', 'cpt_sermons' );
	function cpt_sermons() {
		
		// Define all the labels
		$labels = array(
			'name'               => _x( 'Sermons', 'post type general name', 'cpt' ),
			'singular_name'      => _x( 'Sermon', 'post type singular name', 'cpt' ),
			'menu_name'          => _x( 'CPT Sermons', 'admin menu', 'cpt' ),
			'add_new'            => _x( 'Add New Sermon', 'Sermon', 'cpt' ),
			'add_new_item'       => __( 'Add New Sermon', 'cpt' ),
			'edit_item'          => __( 'Edit Sermon', 'cpt' ),
			'new_item'           => __( 'New Sermon', 'cpt' ),
			'all_items'          => __( 'All Sermons', 'cpt' ),
			'view_item'          => __( 'View Sermon', 'cpt' ),
			'search_items'       => __( 'Search Sermons', 'cpt' ),
			'not_found'          => __( 'No Sermons found', 'cpt' ),
			'not_found_in_trash' => __( 'No Sermons found in the Trash', 'cpt' ), 
			'parent_item_colon'  => ''
		);
		
		$args = array(
			'labels'        		=> $labels,
			'description'   		=> 'Holds the content for the Sermons',
			'public'        		=> true,
			'rewrite'				=> array(
											'slug'	=> 'sermons'
										),
			'menu_icon'				=> 'dashicons-megaphone',
			'capability_type'    	=> 'post',
			'supports'      		=> array( 'title', 'editor', 'thumbnail' ),
			'has_archive'   		=> false,
		);
		
		register_post_type( 'cpt_sermons', $args );	
	}

	add_filter( 'post_updated_messages', 'cpt_sermons_messages' );
	function cpt_sermons_messages( $messages ) {
		global $post, $post_ID;
		$messages['cpt_sermons'] = array(
			0 => '', 
			1 => sprintf( __('Sermon updated. <a href="%s">View Sermon</a>'), esc_url( get_permalink($post_ID) ) ),
			2 => __('Custom field updated.'),
			3 => __('Custom field deleted.'),
			4 => __('Custom field updated.'),
			5 => isset($_GET['revision']) ? sprintf( __('Sermon restored to revision from %s'), wp_post_revision_title( (int) $_GET['revision'], false ) ) : false,
			6 => sprintf( __('Sermon published. <a href="%s">View Sermon</a>'), esc_url( get_permalink($post_ID) ) ),
			7 => __('Sermon saved.'),
			8 => sprintf( __('Sermon submitted. <a target="_blank" href="%s">Preview Sermon</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
			9 => sprintf( __('Sermon scheduled for: <strong>%1$s</strong>. <a target="_blank" href="%2$s">Preview Sermon</a>'), date_i18n( __( 'M j, Y @ G:i' ), strtotime( $post->post_date ) ), esc_url( get_permalink($post_ID) ) ),
			10 => sprintf( __('Sermon draft updated. <a target="_blank" href="%s">Preview Sermon</a>'), esc_url( add_query_arg( 'preview', 'true', get_permalink($post_ID) ) ) ),
		);
		return $messages;
	}

?>