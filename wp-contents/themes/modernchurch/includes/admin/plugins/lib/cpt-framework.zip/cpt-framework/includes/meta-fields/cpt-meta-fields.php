<?php

//include the main class file
require_once("includes/my-meta-box-class.php");

if (is_admin()){
  /* 
   * prefix of meta keys, optional
   * use underscore (_) at the beginning to make keys hidden, for example $prefix = '_ba_';
   *  you also can make prefix empty to disable it
   * 
   */
  $prefix = 'cpt_';



  /* 
   * configure CPT Global meta box
   */
  $cpt_global_config = array(
    'id'             => 'cpt_global',            // meta box id, unique per meta box
    'title'          => 'Global Fields',   // meta box title
    'pages'          => array('cpt_events', 'cpt_locations', 'cpt_sermons', 'cpt_staff', 'cpt_slider', 'post', 'page'),      // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                   // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                     // order of meta box: high (default), low; optional
    'fields'         => array(),                    // list of meta fields (can be added by field arrays)
    'local_images'   => false,                      // Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => false                       //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
  );
  
  
  /*
   * Initiate CPT Global meta box
   */
  $cpt_global_meta =  new AT_Meta_Box($cpt_global_config);
  
  /*
   * Add fields to your meta box
   */

  // Page Title Layout
  $cpt_global_meta->addSelect($prefix.'page_title_layout',array('large_left'=>'Large: Left Aligned','large_center'=>'Large: Center Aligned','small_left'=>'Small: Left Aligned','small_center'=>'Small: Center Aligned'),array('name'=> 'Page Title Layout ', 'std'=> array('large_left')));

  // Breadcrumb
  $cpt_global_meta->addSelect($prefix.'breadcrumb',array('show_breadcrumb'=>'Show Breadcrumb', 'hide_breadcrumb'=>'Hide Breadcrumb'),array('name'=> 'Breadcrumb', 'std'=> array('show_breadcrumb')));

  // Sidebar
  $cpt_global_meta->addSelect($prefix.'side_bar',array('no_sidebar'=>'No Sidebar','left_sidebar'=>'Left Sidebar','right_sidebar'=>'Right Sidebar'),array('name'=> 'Sidebar', 'std'=> array('no_sidebar')));

  /*
   * Don't Forget to Close up the CPT Global meta box Declaration 
   */
  //Finish CPT Global meta Declaration 
  $cpt_global_meta->Finish();
  

  /* 
   * configure CPT Events meta box
   */
  $cpt_events_config = array(
    'id'             => 'cpt_events',            // meta box id, unique per meta box
    'title'          => 'CPT Event Fields',   // meta box title
    'pages'          => array('cpt_events'),      // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                   // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                     // order of meta box: high (default), low; optional
    'fields'         => array(),                    // list of meta fields (can be added by field arrays)
    'local_images'   => false,                      // Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => false                       //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
  );
  
  
  
  /*
   * Initiate CPT Events meta box
   */
  $cpt_events_meta =  new AT_Meta_Box($cpt_events_config);
  
  /*
   * Add fields to your meta box
   */
  
  // Start date field
  $cpt_events_meta->addDate($prefix.'start_date',array('name'=> 'Start Date '));
  
  // End date field
  $cpt_events_meta->addDate($prefix.'end_date',array('name'=> 'End Date '));

  // Location field
  $cpt_events_meta->addText($prefix.'event_location',array('name'=> 'Location '));

  // Time field
  $cpt_events_meta->addText($prefix.'event_time',array('name'=> 'Time '));

  
  /*
   * Don't Forget to Close up the CPT Events meta box Declaration 
   */
  //Finish CPT Events meta Declaration 
  $cpt_events_meta->Finish();


  /* 
   * configure CPT Locations meta box
   */
  $cpt_locations_config = array(
    'id'             => 'cpt_locations',            // meta box id, unique per meta box
    'title'          => 'CPT Locations Fields',   // meta box title
    'pages'          => array('cpt_locations'),      // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                   // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                     // order of meta box: high (default), low; optional
    'fields'         => array(),                    // list of meta fields (can be added by field arrays)
    'local_images'   => false,                      // Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => false                       //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
  );
  
  
  /*
   * Initiate CPT Locations meta box
   */
  $cpt_locations_meta =  new AT_Meta_Box($cpt_locations_config);
  
  /*
   * Add fields to your meta box
   */

  // Location Address Field
  $cpt_locations_meta->addWysiwyg($prefix.'location_address',array('name'=> 'Location Address '));

  // Location Phone Number
  $cpt_locations_meta->addText($prefix.'location_phone',array('name'=> 'Location Contact Details '));

  // Location Email Address
  $cpt_locations_meta->addText($prefix.'email_address',array('name'=> 'Location Email Address '));

  // Location Service Times
  $cpt_locations_meta->addWysiwyg($prefix.'service_times',array('name'=> 'Location Service Times '));

  
  /*
   * Don't Forget to Close up the CPT Locations meta box Declaration 
   */
  //Finish CPT Locations meta Declaration 
  $cpt_locations_meta->Finish();


  /* 
   * configure CPT Sermons meta box
   */
  $cpt_sermons_config = array(
    'id'             => 'cpt_sermons',            // meta box id, unique per meta box
    'title'          => 'CPT Sermons Fields',   // meta box title
    'pages'          => array('cpt_sermons'),      // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                   // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                     // order of meta box: high (default), low; optional
    'fields'         => array(),                    // list of meta fields (can be added by field arrays)
    'local_images'   => false,                      // Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => false                       //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
  );
  
  
  /*
   * Initiate CPT Sermons meta box
   */
  $cpt_sermons_meta =  new AT_Meta_Box($cpt_sermons_config);
  
  /*
   * Add fields to your meta box
   */

  // Sermon Speaker Field
  $cpt_sermons_meta->addText($prefix.'sermon_speaker',array('name'=> 'Speaker '));

  // Sermon Date Field
  $cpt_sermons_meta->addDate($prefix.'sermon_date',array('name'=> 'Sermon Date '));

  // Sermon Audio Field
  $cpt_sermons_meta->addFile($prefix.'sermon_audio',array('name'=> 'Sermon Audio File '));

  // Sermon Video Embed Field
  $cpt_sermons_meta->addTextarea($prefix.'sermon_embed_video',array('name'=> 'Embed Sermon Video '));
  
  /*
   * Don't Forget to Close up the CPT Sermons meta box Declaration 
   */
  //Finish CPT Sermons meta Declaration 
  $cpt_sermons_meta->Finish();



  /* 
   * configure CPT Staff meta box
   */
  $cpt_staff_config = array(
    'id'             => 'cpt_staff',            // meta box id, unique per meta box
    'title'          => 'CPT Staff Fields',   // meta box title
    'pages'          => array('cpt_staff'),      // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                   // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                     // order of meta box: high (default), low; optional
    'fields'         => array(),                    // list of meta fields (can be added by field arrays)
    'local_images'   => false,                      // Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => false                       //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
  );
  
  
  /*
   * Initiate CPT Staff meta box
   */
  $cpt_staff_meta =  new AT_Meta_Box($cpt_staff_config);
  
  /*
   * Add fields to your meta box
   */

  // Staff Name Field
  $cpt_staff_meta->addText($prefix.'staff_name',array('name'=> 'Staff Name '));

  // Staff Position Field
  $cpt_staff_meta->addText($prefix.'staff_position',array('name'=> 'Staff Position '));

  // Staff Phone Field
  $cpt_staff_meta->addText($prefix.'staff_phone',array('name'=> 'Staff Phone Number '));

  // Staff Email Field
  $cpt_staff_meta->addText($prefix.'staff_email',array('name'=> 'Staff Email Address '));
  
  /*
   * Don't Forget to Close up the CPT Staff meta box Declaration 
   */
  //Finish CPT Staff meta Declaration 
  $cpt_staff_meta->Finish();
  

  /* 
   * configure CPT Slider meta box
   */
  $cpt_slider_config = array(
    'id'             => 'cpt_slider',            // meta box id, unique per meta box
    'title'          => 'Slider Fields',   // meta box title
    'pages'          => array('cpt_slider'),      // post types, accept custom post types as well, default is array('post'); optional
    'context'        => 'normal',                   // where the meta box appear: normal (default), advanced, side; optional
    'priority'       => 'high',                     // order of meta box: high (default), low; optional
    'fields'         => array(),                    // list of meta fields (can be added by field arrays)
    'local_images'   => false,                      // Use local or hosted images (meta box images for add/remove)
    'use_with_theme' => false                       //change path if used with theme set to true, false for a plugin or anything else for a custom path(default false).
  );
  
  
  /*
   * Initiate CPT Slider meta box
   */
  $cpt_slider_meta =  new AT_Meta_Box($cpt_slider_config);
  
  /*
   * Add fields to your meta box
   */

  // Slider Name Field
  $cpt_slider_meta->addText($prefix.'slider_btn_url',array('name'=> 'BTN Link '));

  // Slider Position Field
  $cpt_slider_meta->addText($prefix.'slider_btn_text',array('name'=> 'BTN Text '));
  
  /*
   * Don't Forget to Close up the CPT Slider meta box Declaration 
   */
  //Finish CPT Slider meta Declaration 
  $cpt_slider_meta->Finish();

}

?>
